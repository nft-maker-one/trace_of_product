package network

import (
	"testing"
)

func TestBroadcast(t *testing.T) {

}
